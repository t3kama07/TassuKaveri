<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/phpmailer/src/PHPMailer.php';
require __DIR__ . '/phpmailer/src/SMTP.php';
require __DIR__ . '/phpmailer/src/Exception.php';

// Database
$host = "localhost";
$user = "tasslszw_tassu_user";
$pass = "Priyanath@1990";
$db   = "tasslszw_tassu_db";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("DB error");
}

if (!isset($_POST['email']) || empty($_POST['email'])) {
    die("no email");
}

$email = trim($_POST['email']);

// Save to DB
$stmt = $conn->prepare("INSERT INTO subscribers (email) VALUES (?)");
$stmt->bind_param("s", $email);
$stmt->execute();

// Send email
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'server704.web-hosting.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'no-reply@tassukaveri.fi';
    $mail->Password   = 'Priyanath@1990'; 
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port       = 465;

    $mail->setFrom('no-reply@tassukaveri.fi', 'TassuKaveri');
    $mail->addAddress($email);

    $mail->Subject = "Tervetuloa TassuKaveriin!";
    $mail->isHTML(true);

    // Load HTML email template
    $mail->Body = file_get_contents(__DIR__ . '/email_template.html');

    $mail->send();
    echo "success";

} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}
?>
